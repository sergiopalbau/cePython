from clases import *

# Pelis de productora
# lista = ListMovies.movies_producer("Warner Bros. Pictures")
# print(*lista, sep="\n")

# Pelis cadena "wo"

# lista = ListMovies.movies_string("wo")
# print(*lista, sep="\n")

# nº pelis q superan duracioin media
# print(ListMovies.minutes_greater_avg())

# Sort
ListMovies.sort_by_minutes(rev=False)
ListMovies.show_movies()



