from clases import Mates

print(Mates.mayor(1,2))
print(Mates.producto(10, 20))
print(Mates.potencia(2, 3))