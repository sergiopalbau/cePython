class Mates:

    @staticmethod
    def mayor(a, b):
        if a > b:
            return a
        else:
            return b 
    
    @staticmethod
    def producto(a, b):
        return a * b 
    
    @staticmethod
    def potencia(base, exponente):
        return base ** exponente