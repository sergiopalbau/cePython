from Partido import Partido

partido1 = Partido ("equipo1", "equipo2",3,0)
partido2 = Partido("equipo3", "equipo4",2,5)

print (partido1.local, " vs ", partido1.visitante)
print (partido2.local, " vs ", partido2.visitante)